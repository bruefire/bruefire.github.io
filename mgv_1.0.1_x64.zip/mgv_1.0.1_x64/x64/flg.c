#version 330 core

in vec2 txr;
uniform sampler2D sfTex;
out vec4 color;


void main() {
	color.rgba = texture(sfTex, txr).rgba;

}