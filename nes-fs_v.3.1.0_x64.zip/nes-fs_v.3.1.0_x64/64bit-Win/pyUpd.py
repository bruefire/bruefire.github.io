
if 'updateCallback' in globals():
    for cbFunc in updateCallback:
        cbFunc()
