(I am not good at english.)

thanks for download this software.
this program is OSS. 
there is no problem with modification, 
redistribtion or etc.


Overview:
this program is simulator to fly 
in "Spherical space" and "Hyperbolic space"
which have diferent 
features from Euclid space.
the source was coded for windows.


=========== Disclaimer ===========
1. I'll not have responsibility about any 
problem by execusion of this program.
2. there is no warranty about quality of 
content in the program.
================================

Windows 32bit exe file location is
./32bit-Win/nes-fs.exe
Windows 64bit exe file location is
./64bit-Win/nes-fs.exe

recommended Windows version: 10
maybe recommended GPU spec: 
 GTX770 or equivalent others.
(I have developed this with GTX770 
and win10)


*********�@Method of operation�@*********
------------- format -------------
[keyboard and mouse / Xbox controller]
 result of operation
---------------------------------

[mid click + drag / right stick]
 change FOV(rotation).

[Shift + mouse wheel / L-R button]
 change FOV(rotation).

[mouse wheel / L-R trigger]
 move forward or back.

[Shift + mid click + drag / left stick]
 move to upper, lower, left, or right side.

[space key / B button]
 stop or re-activate objects.

[1 key / X button]
change move speed.

[2 key / A button]
 shoot a object forward.

[3 key / Y button]
 change the operated object.

[4 key / up arrow key]
 change map mode to front/bird's-eye.

[5 key / left arrow key]
 change map mode to single/dual.

#maybe other controllers can be used this program.
but I don't know button layout about others. 


*************�@About VR mode�@*************
hardwares that This software is apadpted to is only OculusRift/Quest.
if you have a bad feeling, please stop playing and take a rest.

models of "Izumo Oyashiro", Tori, and so on 
were downloaded and used from here:
http://www.3dchaya.com/
----------------------------------
NES-FS (Non Euclidean Space Flight Simlator)
version: 3.1.0
release: Mar.2021
creator: bruefire