#version 330 core

layout(location = 0) in vec2 vPos;
layout(location = 1) in vec2 TXR;

uniform vec4 state;	// left, top, width, height

out vec2 txr;


void main() {

	gl_Position = vec4(
		vPos.x * state[2] + state[0] -1, 
		vPos.y * state[3] - state[1] +1, 
		0, 
		1
	);
	txr = TXR;

}