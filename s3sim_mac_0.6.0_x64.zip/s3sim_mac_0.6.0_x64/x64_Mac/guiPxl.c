#version 120


uniform vec4 bkColor;

void main()
{
	gl_FragColor = bkColor;
}