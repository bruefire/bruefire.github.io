#version 120

// Ouput data
varying vec3 col;
uniform float alpha;

//----------------------------------------
void main()
{

	gl_FragColor = vec4(col.xyz, alpha);
	if(alpha < -0.1)
		gl_FragColor = vec4(0.0, 0.0, 0.0, 0.1);

}
