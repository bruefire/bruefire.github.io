#version 120

// Ouput data

uniform vec3 cols;
uniform sampler2D sfTex;


//----------------------------------------
void main()
{

	gl_FragColor = vec4(1.0,1.0,0.0,1.0);
	gl_FragDepth = 0.5;
}

